import { NextResponse } from "next/server"

// Array of canned responses
const cannedResponses = [
  "Hello there! How can I help you today?",
  "That's an interesting question. Let me think about that.",
  "I understand your concern. Here's what I suggest...",
  "Thanks for sharing that with me!",
  "I'm just a simple chat bot with pre-programmed responses.",
  "Could you tell me more about that?",
  "I'm here to assist you with any questions you might have.",
  "That's a great point! I hadn't thought of it that way.",
  "I appreciate your patience.",
  "Let me know if there's anything else I can help with!",
]

export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    const { message } = body

    // Simulate a delay to make it feel more natural
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Get a random response from our canned responses
    const randomIndex = Math.floor(Math.random() * cannedResponses.length)
    const response = cannedResponses[randomIndex]

    // Return the response
    return NextResponse.json({ response })
  } catch (error) {
    console.error("Error processing chat message:", error)
    return NextResponse.json({ error: "Failed to process your message" }, { status: 500 })
  }
}

